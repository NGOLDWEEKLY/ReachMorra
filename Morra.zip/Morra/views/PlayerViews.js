import React from 'react';

const exports = {};

// Player views must be extended.
// It does not have its own Wrapper view.

exports.GetVal = class extends React.Component {
  render() {
    const {parent, playable, val} = this.props;
    return (
      <div>
        <p>Play your finger. (0 to 5)</p>
        <button
          disabled={!playable}
          onClick={() => parent.setVal('0')}
        >0</button>
        <button
          disabled={!playable}
          onClick={() => parent.setVal('1')}
        >1</button>
        <button
          disabled={!playable}
          onClick={() => parent.setVal('2')}
        >2</button>
        <button
          disabled={!playable}
          onClick={() => parent.setVal('3')}
        >3</button>
        <button
          disabled={!playable}
          onClick={() => parent.setVal('4')}
        >4</button>
        <button
          disabled={!playable}
          onClick={() => parent.setVal('5')}
        >5</button>
      </div>
    );
  }
}
exports.GetGuessVal = class extends React.Component {
  render() {
    const {parent, playable, val} = this.props;
    return (
      <div>
      <p>Shout a number.(0 to 10)</p>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(0)}
        >0</button>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(1)}
        >1</button>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(2)}
        >2</button>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(3)}
        >3</button>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(4)}
        >4</button>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(5)}
        >5</button>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(6)}
        >6</button>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(7)}
        >7</button>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(8)}
        >8</button>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(9)}
        >9</button>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(10)}
        >10</button>
      </div>
    );
  }
}

exports.WaitingForResults = class extends React.Component {
  render() {
    return (
      <div>
        Waiting for results...
      </div>
    );
  }
}

exports.Done = class extends React.Component {
  render() {
    const {outcome} = this.props;
    return (
      <div>
        Thank you for playing. The outcome of this game was:
        <br />{outcome || 'Unknown'}
      </div>
    );
  }
}

exports.Timeout = class extends React.Component {
  render() {
    return (
      <div>
        There's been a timeout. (Someone took too long.)
      </div>
    );
  }
}

export default exports;
